<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/style.css">
    <title>Home Page</title>
</head>
<body>
    <div id="container">
        <div class="content">
            <h3>Lista de Exercícios para menção 31-10-2023 – SWI</h3>
            <h3>Isabela Guessi – 2º informática⍟</h3>

            <h4><strong>Função do framework laravel, respostas no word</strong></h4>
            <p>☆</p>
            
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-isa\resources\views/isabela.blade.php ENDPATH**/ ?>